# 👗 Website thời trang Anh Quí Quận 11

Website bán đồ thời trang màu hồng pastel, xây dựng phục vụ môn **Thương mại điện tử**.

## ✨ Thông tin
- Thương hiệu: **Anh Quí Quận 11**
- Liên hệ: **Zalo 0818 877 128 (Anh Quí)**
- Giao diện: màu hồng - trắng, thân thiện
- Tính năng: tìm kiếm, thêm/xóa giỏ hàng, xem tổng giá

## ⚙️ Công nghệ
HTML, CSS, JavaScript (thuần)

---
💖 *Thiết kế bởi Anh Quí - Quận 11*
