const products = [
  { id: 1, name: "Áo thun hồng", price: 150000, img: "images/ao1.jpg" },
  { id: 2, name: "Váy trắng dễ thương", price: 320000, img: "images/vay1.jpg" },
  { id: 3, name: "Quần jean nữ", price: 280000, img: "images/quan1.jpg" },
  { id: 4, name: "Túi xách thời trang", price: 250000, img: "images/tui1.jpg" },
  { id: 5, name: "Giày sneaker", price: 450000, img: "images/giay1.jpg" },
  { id: 6, name: "Áo khoác hồng pastel", price: 380000, img: "images/aokhoac1.jpg" },
];

const productContainer = document.getElementById("products");
const searchInput = document.getElementById("search");
const cartBtn = document.getElementById("cart-btn");
const cartAside = document.getElementById("cart");
const closeCartBtn = document.getElementById("close-cart");
const cartItemsEl = document.getElementById("cart-items");
const cartTotalEl = document.getElementById("cart-total");
const cartCountEl = document.getElementById("cart-count");

let cart = [];

function renderProducts(list) {
  productContainer.innerHTML = "";
  list.forEach(p => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = `
      <img src="${p.img}" alt="${p.name}">
      <h3>${p.name}</h3>
      <p>${p.price.toLocaleString()}₫</p>
      <button onclick="addToCart(${p.id})">Thêm vào giỏ</button>
    `;
    productContainer.appendChild(div);
  });
}

function addToCart(id) {
  const item = products.find(p => p.id === id);
  const existing = cart.find(i => i.id === id);
  if (existing) existing.qty++;
  else cart.push({ ...item, qty: 1 });
  updateCart();
}

function updateCart() {
  cartItemsEl.innerHTML = "";
  let total = 0;
  cart.forEach(item => {
    total += item.price * item.qty;
    const li = document.createElement("li");
    li.textContent = `${item.name} x${item.qty} - ${(item.price * item.qty).toLocaleString()}₫`;
    cartItemsEl.appendChild(li);
  });
  cartTotalEl.textContent = `Tổng: ${total.toLocaleString()}₫`;
  cartCountEl.textContent = cart.length;
}

searchInput.addEventListener("input", e => {
  const val = e.target.value.toLowerCase();
  const filtered = products.filter(p => p.name.toLowerCase().includes(val));
  renderProducts(filtered);
});

cartBtn.addEventListener("click", () => cartAside.classList.toggle("hidden"));
closeCartBtn.addEventListener("click", () => cartAside.classList.add("hidden"));

renderProducts(products);